<script type="text/javascript">
    window.location.replace(window.location.protocol + '//' + window.location.hostname + '/wp-admin');
</script>